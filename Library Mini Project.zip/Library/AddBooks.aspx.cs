﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddBooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void main_addbook_Click(object sender, EventArgs e)
    {
        Bookmodel model = new Bookmodel();
        model.BookName = txt_bname.Text;
        model.AuthorName = txt_bauthor.Text;

        model.BookImage = "~/Images/" + Guid.NewGuid() + ".jpg";
        txt_bimage.SaveAs(Server.MapPath(model.BookImage));

        StudentDAL dal = new StudentDAL();
        int id = dal.Addbook(model);
        lbl_mag.Text = "New Book Added:" + id;
        image.ImageUrl = model.BookImage;
    }
}