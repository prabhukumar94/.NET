create database Librarysite
use Librarysite

create table tbl_Books
(
BookId int identity(501,1) not null,
BookName varchar(100)not null,
AuthorName varchar(100)not null,
BookImage varchar(100) not null,
BookaddedDate Datetime
)

create table tbl_students
(
StudentId int identity(101,1) not null,
StudentName varchar(100) not null,
StudentEmilId varchar(100) not null,
StudentDoB datetime not null,
StudentPassword varchar(100) not null,
StudentGender varchar(100) not null,
Studentimage varchar(100)
)


create proc proc_Addstudent(@name varchar(100),@email varchar(100),@dob datetime,
		@pwd varchar(100),@gender varchar(100),@image varchar(100))
		as
		begin
		insert tbl_students values(@name,@email,@dob,@pwd,@gender,@image);
		return @@identity
		end

create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_students
where StudentId=@id and StudentPassword=@pwd
return @count
end

alter proc prco_find(@id int)
as
begin
select * from tbl_students where StudentId=@id
end


create proc proc_Addbook(@bookname varchar(100),@Aname varchar(100),@bookimage varchar(100) )
as
begin
insert tbl_Books values(@bookname,@Aname,@bookimage,getdate());
return @@identity
end

create proc proc_search(@key varchar(100))
as
begin
select * from tbl_Books where BookId like '%'+@key+'%'
			or BookName like '%'+@key+'%'
	end





