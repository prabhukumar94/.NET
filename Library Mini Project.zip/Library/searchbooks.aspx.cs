﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class searchbooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_search_Click(object sender, EventArgs e)
    {
        StudentDAL dal = new StudentDAL();
        string key = txt_search.Text;
        List<Bookmodel> model = dal.Search(key);
        gv_book.DataSource = model;
        gv_book.DataBind();
    }

    protected void gv_book_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = (gv_book.SelectedRow.FindControl("lbl_bid") as Label);
        int id = Convert.ToInt32(l.Text);
        Response.Redirect("Details.aspx?sid=" + id);
    }
}