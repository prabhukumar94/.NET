﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StudentModel
/// </summary>
public class StudentModel
{
   public int StudentID
    {
        get;
        set;
    }
    public string StudentName
    {
        get;
        set;

    }
    public string StudentEmail
    {
        get;
        set;
    }
    public DateTime StudentDob
    {
        get;
        set;
    }
    public string StudentPassword
    {
        get;
        set;
    }
    public string StudentGender
    {
        get;
        set;
    }
    public string StudentImage
    {
        get;
        set;
    }
}