﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Bookmodel
/// </summary>
public class Bookmodel
{
    public int BookId
    {
        get;
        set;

    }
    public string BookName
    {
        get;
        set;
    }
    public string AuthorName
    {
        get;
        set;
    }
    public string BookImage
    {
        get;
        set;
    }
    public DateTime BookAddedDate
    {
        get;
        set;
    }
}