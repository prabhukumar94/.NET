﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for StudentDAL
/// </summary>
public class StudentDAL
{

    SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


    public int AddStudent(StudentModel model)
    {
        try
        {
            SqlCommand com_stud = new SqlCommand("proc_Addstudent", con);
            com_stud.CommandType = CommandType.StoredProcedure;
            com_stud.Parameters.AddWithValue("@name", model.StudentName);
            com_stud.Parameters.AddWithValue("@email", model.StudentEmail);
            com_stud.Parameters.AddWithValue("@dob", model.StudentDob);
            com_stud.Parameters.AddWithValue("@pwd", model.StudentPassword);
            com_stud.Parameters.AddWithValue("@gender", model.StudentGender);
            com_stud.Parameters.AddWithValue("@image", model.StudentImage);
            SqlParameter Para_return = new SqlParameter();
            Para_return.Direction = ParameterDirection.ReturnValue;
            com_stud.Parameters.Add(Para_return);
            con.Open();
            com_stud.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(Para_return.Value);
            return id;


        }
        finally
        {
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }

    public int Addbook(Bookmodel model)
    {
        try
        {
            SqlCommand com_book = new SqlCommand("proc_Addbook", con);
            com_book.CommandType = CommandType.StoredProcedure;
            com_book.Parameters.AddWithValue("@bookname", model.BookName);
            com_book.Parameters.AddWithValue("@Aname", model.AuthorName);
            com_book.Parameters.AddWithValue("@bookimage", model.BookImage);
            SqlParameter Para_return = new SqlParameter();
            Para_return.Direction = ParameterDirection.ReturnValue;
            com_book.Parameters.Add(Para_return);
            con.Open();
            com_book.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(Para_return.Value);
            return id;

        }
        finally
        {
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }

    public bool login(int id, string password)
    {
        try
        {
            SqlCommand com_login = new SqlCommand("proc_login", con);
            com_login.CommandType = CommandType.StoredProcedure;
            com_login.Parameters.AddWithValue("@id", id);
            com_login.Parameters.AddWithValue("@pwd", password);
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(para_return);
            con.Open();
            com_login.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        finally
        {
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }



    }
    public List<Bookmodel> Search(string key)
    {
        try
        {
            SqlCommand com_search = new SqlCommand("proc_search", con);
            com_search.CommandType = CommandType.StoredProcedure;
            com_search.Parameters.AddWithValue("@key", key);
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Bookmodel> Booklist = new List<Bookmodel>();
            while(dr.Read())
            {
                Bookmodel model = new Bookmodel();
                model.BookId = dr.GetInt32(0);
                model.BookName = dr.GetString(1);
                model.AuthorName = dr.GetString(2);
                model.BookImage = dr.GetString(3);
                model.BookAddedDate = dr.GetDateTime(4);
                Booklist.Add(model);

            }
            con.Close();
            return Booklist;
        }
        finally
        {
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }

    public List<StudentModel> find(int id)
    {
        try
        {
            SqlCommand com_find = new SqlCommand("prco_find", con);
            com_find.CommandType = CommandType.StoredProcedure;
            com_find.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            List<StudentModel> studentlist = new List<StudentModel>();
            while (dr.Read())
            {
                StudentModel model = new StudentModel();
                model.StudentID = dr.GetInt32(0);
                model.StudentName = dr.GetString(1);
                model.StudentEmail = dr.GetString(2);
                model.StudentDob = dr.GetDateTime(3);
                model.StudentPassword = dr.GetString(4);
                model.StudentGender = dr.GetString(5);
                model.StudentImage = dr.GetString(6);
                studentlist.Add(model);
            }
            con.Close();
            return studentlist;
        }
        finally
        {
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
}