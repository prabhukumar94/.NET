﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        int login = Convert.ToInt32(txt_login.Text);
        string password = txt_password.Text;
        StudentDAL dal = new StudentDAL();
        bool status = dal.login(login, password);
        
            if (status == true)
            {
                Session["loginid"] = login;
                Response.Redirect("Studenthome.aspx");
            }
            else
            {
                lbl_msg.Text = "invaid user";
            }
        
        






    }
}