﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class searchstudent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_find_Click(object sender, EventArgs e)
    {
        StudentDAL dal = new StudentDAL();
        int id = Convert.ToInt32(txt_find.Text);
        List<StudentModel> model = dal.find(id);
        gv_student.DataSource = model;
        gv_student.DataBind();
    }

    protected void gv_student_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = (gv_student.SelectedRow.FindControl("lbl_sid") as Label);
        int id = Convert.ToInt32(l.Text);
        Response.Redirect("Details.aspx?sid=" + id);
    }

   

}