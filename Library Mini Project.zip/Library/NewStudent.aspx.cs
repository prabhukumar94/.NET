﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewStudent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_student_Click(object sender, EventArgs e)
    {
        StudentModel model = new StudentModel();
        model.StudentName = txt_name.Text;
        model.StudentEmail = txt_email.Text;
        model.StudentDob = Convert.ToDateTime(txt_date.Text);
        model.StudentPassword = txt_password.Text;
        model.StudentGender = string.Empty;
        if(r_male.Checked==true)
        {
            model.StudentGender = "Male";
        }
        else
        {
            model.StudentGender = "Female";
        }
        model.StudentImage = "~/Images/" + Guid.NewGuid() + ".jpg";
        txt_file.SaveAs(Server.MapPath(model.StudentImage));

        StudentDAL dal = new StudentDAL();
        int id = dal.AddStudent(model);
        lbl_mag.Text = "New Student Added:" + id;
        img.ImageUrl = model.StudentImage;
    }
}